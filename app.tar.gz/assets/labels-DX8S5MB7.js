const s=r=>{const t=(r??"").trim();return t?/^صندوق(\s|$)/.test(t)?t:`صندوق ${t}`:"صندوق"},e=r=>{const t=(r??"").trim();return t?/^[\d٠-٩\s.,،\-–—ـ]+$/.test(t)?"":t:""};export{s as b,e as c};
