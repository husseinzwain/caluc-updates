import{u as g,w as v}from"./xlsx-BZe_PqlR.js";import{A as m,am as x}from"./index-D0m2ciJ6.js";function t(n){return String(n??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function y(n,e,i,d){const s=g.aoa_to_sheet([i,...d]);s["!cols"]=i.map((p,o)=>{const a=Math.max(p.length,...d.map(l=>String(l[o]??"").length));return{wch:Math.min(Math.max(a+2,10),40)}}),s["!views"]||(s["!views"]=[]),s["!views"].push({RTL:!0});const r=g.book_new();r.Workbook={Views:[{RTL:!0}]},g.book_append_sheet(r,s,e),v(r,n)}function $(n,e){const i=window.open("","_blank","width=900,height=700");return i?(i.document.write(`<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
<meta charset="utf-8" />
<title>${t(n)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet" />
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; color: #1a1a1a; padding: 24px; direction: rtl; }
  h1 { font-size: 20px; margin-bottom: 4px; }
  h2 { font-size: 15px; color: #555; font-weight: 600; margin-bottom: 16px; }
  table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }
  th, td { border: 1px solid #ccc; padding: 7px 10px; text-align: right; }
  th { background: #f3f4f6; font-weight: 700; }
  tr:nth-child(even) td { background: #fafafa; }
  .meta { font-size: 12px; color: #666; margin-top: 6px; }
  .footer { margin-top: 24px; font-size: 11px; color: #888; text-align: center; border-top: 1px dashed #ccc; padding-top: 10px; }
  .receipt { max-width: 420px; margin: 0 auto; border: 1px solid #ddd; border-radius: 8px; padding: 20px; }
  .receipt-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed #e5e5e5; font-size: 14px; }
  .receipt-row .label { color: #666; }
  .receipt-row .value { font-weight: 700; }
  .receipt-title { text-align: center; margin-bottom: 14px; }
  .receipt-title h1 { font-size: 18px; }
  .amount-big { text-align: center; font-size: 24px; font-weight: 700; margin: 14px 0; padding: 10px; background: #f3f4f6; border-radius: 8px; }
  .neg { color: #dc2626; }
  .pos { color: #16a34a; }
  @media print { body { padding: 8px; } .no-print { display: none; } }
</style>
</head>
<body>${e}</body>
</html>`),i.document.close(),i.focus(),setTimeout(()=>{i.print()},600),!0):!1}function u(n){const{title:e,subtitle:i,amountText:d,fields:s,footerNote:r,qrDataUrl:p,showSystemName:o=!0}=n,a=r||(o?"نظام سوفت للإدارة المالية — صرافة وحوالات":"");return`
<div class="receipt">
  <div class="receipt-title">
    <h1>${t(e)}</h1>
    ${i?`<div class="meta">${t(i)}</div>`:""}
  </div>
  ${d?`<div class="amount-big">${t(d)}</div>`:""}
  ${s.map(l=>`<div class="receipt-row"><span class="label">${t(l.label)}</span><span class="value">${t(l.value)}</span></div>`).join("")}
  ${p&&p.startsWith("data:image/")?`<div style="text-align:center;margin-top:14px"><img src="${p}" alt="QR" style="width:110px;height:110px" /><div class="meta" style="margin-top:4px">امسح الرمز للتحقق من صحة الوصل</div></div>`:""}
  <div class="footer">${a?`${t(a)}<br/>`:""}طُبع في: ${t(m(new Date))}</div>
</div>`}function w(n){const{branding:e,customerName:i,customerPhone:d,balanceLines:s,headers:r,rows:p,summaryLines:o}=n,a=e?.office_name?.trim()||"نظام سوفت للإدارة المالية";return`
<div style="display:flex;align-items:center;justify-content:space-between;gap:16px;border-bottom:3px solid #1a1a1a;padding-bottom:14px;margin-bottom:16px">
  <div style="display:flex;align-items:center;gap:14px">
    ${!!e?.logo&&/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(e.logo)?`<img src="${e.logo}" alt="شعار" style="width:64px;height:64px;object-fit:contain" />`:""}
    <div>
      <div style="font-size:20px;font-weight:700">${t(a)}</div>
      ${e?.phone?`<div class="meta">هاتف: <span dir="ltr">${t(e.phone)}</span></div>`:""}
      ${e?.address?`<div class="meta">${t(e.address)}</div>`:""}
    </div>
  </div>
  <div style="text-align:left">
    <div style="font-size:17px;font-weight:700;background:#f3f4f6;border-radius:8px;padding:6px 16px">كشف حساب</div>
    <div class="meta" style="margin-top:6px">التاريخ: ${t(x(new Date))}</div>
  </div>
</div>
<div style="display:flex;flex-wrap:wrap;gap:8px 24px;background:#fafafa;border:1px solid #eee;border-radius:8px;padding:10px 14px;margin-bottom:6px">
  <div><span style="color:#666;font-size:12px">العميل: </span><span style="font-weight:700">${t(i)}</span></div>
  ${d?`<div><span style="color:#666;font-size:12px">الهاتف: </span><span style="font-weight:700" dir="ltr">${t(d)}</span></div>`:""}
  ${(s||[]).map(c=>`<div style="font-weight:700">${t(c)}</div>`).join("")}
</div>
<table>
  <thead><tr>${r.map(c=>`<th>${t(c)}</th>`).join("")}</tr></thead>
  <tbody>
    ${p.map(c=>`<tr>${c.map(f=>`<td>${t(f)}</td>`).join("")}</tr>`).join("")}
  </tbody>
</table>
${(o||[]).map(c=>`<div class="meta" style="margin-top:10px;font-weight:700">${t(c)}</div>`).join("")}
<div style="display:flex;justify-content:space-between;margin-top:40px;font-size:13px">
  <div style="text-align:center;min-width:160px">توقيع المكتب<div style="border-top:1px solid #999;margin-top:34px"></div></div>
  <div style="text-align:center;min-width:160px">توقيع العميل<div style="border-top:1px solid #999;margin-top:34px"></div></div>
</div>
<div class="footer">${t(a)} · طُبع في: ${t(m(new Date))}</div>`}function j(n){const{branding:e,title:i,subtitle:d,sections:s,footerLines:r}=n,p=e?.office_name?.trim()||"نظام سوفت للإدارة المالية";return`
<div style="display:flex;align-items:center;justify-content:space-between;gap:16px;border-bottom:3px solid #1a1a1a;padding-bottom:14px;margin-bottom:16px">
  <div style="display:flex;align-items:center;gap:14px">
    ${!!e?.logo&&/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(e.logo)?`<img src="${e.logo}" alt="شعار" style="width:64px;height:64px;object-fit:contain" />`:""}
    <div>
      <div style="font-size:20px;font-weight:700">${t(p)}</div>
      ${e?.phone?`<div class="meta">هاتف: <span dir="ltr">${t(e.phone)}</span></div>`:""}
      ${e?.address?`<div class="meta">${t(e.address)}</div>`:""}
    </div>
  </div>
  <div style="text-align:left">
    <div style="font-size:17px;font-weight:700;background:#f3f4f6;border-radius:8px;padding:6px 16px">${t(i)}</div>
    <div class="meta" style="margin-top:6px">التاريخ: ${t(x(new Date))}</div>
  </div>
</div>
${d?`<h2>${t(d)}</h2>`:""}
${s.filter(a=>a.fields.length>0).map(a=>`
<div style="margin-bottom:16px">
  <div style="font-size:14px;font-weight:700;background:#f3f4f6;border-radius:6px;padding:5px 12px;margin-bottom:8px">${t(a.title)}</div>
  <table style="margin-top:0">
    <tbody>
      ${a.fields.map(l=>`<tr><td style="width:35%;color:#666;background:#fafafa">${t(l.label)}</td><td style="font-weight:600">${t(l.value)}</td></tr>`).join("")}
    </tbody>
  </table>
</div>`).join("")}
${(r||[]).map(a=>`<div class="meta" style="margin-top:8px;font-weight:700">${t(a)}</div>`).join("")}
<div style="display:flex;justify-content:space-between;margin-top:40px;font-size:13px">
  <div style="text-align:center;min-width:160px">توقيع المكتب<div style="border-top:1px solid #999;margin-top:34px"></div></div>
  <div style="text-align:center;min-width:160px">توقيع العميل<div style="border-top:1px solid #999;margin-top:34px"></div></div>
</div>
<div class="footer">${t(p)} · طُبع في: ${t(m(new Date))}</div>`}function z(n){const{title:e,subtitle:i,metaLines:d,headers:s,rows:r,summaryLines:p}=n;return`
<h1>${t(e)}</h1>
${i?`<h2>${t(i)}</h2>`:""}
${(d||[]).map(o=>`<div class="meta">${t(o)}</div>`).join("")}
<table>
  <thead><tr>${s.map(o=>`<th>${t(o)}</th>`).join("")}</tr></thead>
  <tbody>
    ${r.map(o=>`<tr>${o.map(a=>`<td>${t(a)}</td>`).join("")}</tr>`).join("")}
  </tbody>
</table>
${(p||[]).map(o=>`<div class="meta" style="margin-top:10px;font-weight:700">${t(o)}</div>`).join("")}
<div class="footer">نظام سوفت للإدارة المالية — صرافة وحوالات · طُبع في: ${t(m(new Date))}</div>`}export{w as a,j as b,u as c,z as d,y as e,t as f,$ as o};
